package classdemo1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class EchoServer {
    public static final int DEFAULT_PORT = 2345;

    public static void main(String[] args) {

    }
}
